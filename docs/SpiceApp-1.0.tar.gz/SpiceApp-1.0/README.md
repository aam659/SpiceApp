# SpiceApp
A mobile app designed to provide members with a wide variety of possible dining venues through the utilization of several algorithms based on user preferences.

# Website
https://aam659.github.io/SpiceApp/
